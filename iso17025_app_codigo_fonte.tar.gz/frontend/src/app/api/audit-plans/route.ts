// src/app/api/audit-plans/route.ts
import { NextResponse } from 'next/server';

// Dados de exemplo para planos de auditoria
const auditPlans = [
  {
    id: 1,
    title: 'Auditoria Anual Laboratório Central',
    description: 'Auditoria completa de todos os requisitos da ISO 17025:2017',
    startDate: '2025-05-10',
    endDate: '2025-05-20',
    status: 'active',
    progress: 25,
    createdBy: 1,
    createdAt: '2025-04-01T10:00:00Z',
    updatedAt: '2025-04-15T14:30:00Z'
  },
  {
    id: 2,
    title: 'Auditoria Semestral - Setor de Calibração',
    description: 'Auditoria focada nos requisitos técnicos para o setor de calibração',
    startDate: '2025-06-15',
    endDate: '2025-06-18',
    status: 'draft',
    progress: 0,
    createdBy: 1,
    createdAt: '2025-04-10T09:15:00Z',
    updatedAt: '2025-04-10T09:15:00Z'
  },
  {
    id: 3,
    title: 'Auditoria de Acompanhamento - Não Conformidades',
    description: 'Verificação das ações corretivas implementadas após a última auditoria',
    startDate: '2025-04-05',
    endDate: '2025-04-07',
    status: 'completed',
    progress: 100,
    createdBy: 2,
    createdAt: '2025-03-20T11:30:00Z',
    updatedAt: '2025-04-08T16:45:00Z'
  },
];

// GET - Obter todos os planos de auditoria
export async function GET(request: Request) {
  try {
    // Em uma implementação real, isso buscaria dados do banco de dados
    return NextResponse.json({ success: true, data: auditPlans });
  } catch (error) {
    console.error('Erro ao buscar planos de auditoria:', error);
    return NextResponse.json(
      { success: false, message: 'Erro ao buscar planos de auditoria' },
      { status: 500 }
    );
  }
}

// POST - Criar um novo plano de auditoria
export async function POST(request: Request) {
  try {
    const data = await request.json();
    
    // Validação básica
    if (!data.title || !data.startDate || !data.endDate) {
      return NextResponse.json(
        { success: false, message: 'Dados incompletos. Título, data de início e data de término são obrigatórios.' },
        { status: 400 }
      );
    }
    
    // Simulação de criação - em produção, isso seria salvo no banco de dados
    const newPlan = {
      id: auditPlans.length + 1,
      ...data,
      status: data.status || 'draft',
      progress: 0,
      createdBy: 1, // Simulando o usuário atual
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    
    // Em produção, isso seria uma inserção no banco de dados
    auditPlans.push(newPlan);
    
    return NextResponse.json({ success: true, data: newPlan });
  } catch (error) {
    console.error('Erro ao criar plano de auditoria:', error);
    return NextResponse.json(
      { success: false, message: 'Erro ao criar plano de auditoria' },
      { status: 500 }
    );
  }
}
