// src/app/api/auth/route.ts
import { NextResponse } from 'next/server';

export async function POST(request: Request) {
  try {
    const { email, password } = await request.json();
    
    // Simulação de autenticação - em produção, isso seria verificado contra o banco de dados
    if (email === 'admin@exemplo.com' && password === 'senha123') {
      return NextResponse.json({
        success: true,
        user: {
          id: 1,
          name: 'Administrador',
          email: 'admin@exemplo.com',
          role: 'admin'
        },
        token: 'jwt-token-simulado-xyz'
      });
    } else if (email === 'auditor@exemplo.com' && password === 'senha123') {
      return NextResponse.json({
        success: true,
        user: {
          id: 2,
          name: 'Auditor',
          email: 'auditor@exemplo.com',
          role: 'auditor'
        },
        token: 'jwt-token-simulado-abc'
      });
    }
    
    return NextResponse.json(
      { success: false, message: 'Credenciais inválidas' },
      { status: 401 }
    );
  } catch (error) {
    console.error('Erro na autenticação:', error);
    return NextResponse.json(
      { success: false, message: 'Erro no servidor' },
      { status: 500 }
    );
  }
}
