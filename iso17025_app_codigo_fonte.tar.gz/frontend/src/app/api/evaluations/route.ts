// src/app/api/evaluations/route.ts
import { NextResponse } from 'next/server';

// Dados de exemplo para avaliações
const evaluations = [
  {
    id: 1,
    assignment_id: 101,
    requirement_section: '4.1',
    audit_plan_id: 1,
    auditor_id: 2,
    procedures: 'Procedimento P-01 (Imparcialidade) e P-02 (Confidencialidade)',
    records: 'Declarações de imparcialidade assinadas por todos os colaboradores; Registro de análise de riscos à imparcialidade',
    observations: 'O laboratório possui um procedimento bem estabelecido para garantir a imparcialidade. Todos os colaboradores assinaram as declarações de imparcialidade e conflito de interesses.',
    status: 'compliant',
    evidence_files: ['declaracao_imparcialidade.pdf', 'analise_riscos.xlsx'],
    created_at: '2025-04-15T10:30:00Z',
    updated_at: '2025-04-15T10:30:00Z',
    is_synced: true
  },
  {
    id: 2,
    assignment_id: 102,
    requirement_section: '4.2',
    audit_plan_id: 1,
    auditor_id: 2,
    procedures: 'Procedimento P-02 (Confidencialidade)',
    records: 'Acordos de confidencialidade assinados; Política de segurança da informação',
    observations: 'O laboratório mantém acordos de confidencialidade assinados por todos os colaboradores e prestadores de serviço. A política de segurança da informação está implementada.',
    status: 'compliant',
    evidence_files: ['acordos_confidencialidade.pdf', 'politica_seguranca.pdf'],
    created_at: '2025-04-15T11:15:00Z',
    updated_at: '2025-04-15T11:15:00Z',
    is_synced: true
  },
  {
    id: 3,
    assignment_id: 103,
    requirement_section: '5.1',
    audit_plan_id: 1,
    auditor_id: 2,
    procedures: 'Manual da Qualidade (MQ-01)',
    records: 'Contrato social; Alvará de funcionamento',
    observations: 'O laboratório está legalmente constituído, porém o alvará de funcionamento está com a data de renovação próxima.',
    status: 'in_progress',
    evidence_files: ['contrato_social.pdf'],
    created_at: '2025-04-16T09:45:00Z',
    updated_at: '2025-04-16T09:45:00Z',
    is_synced: true
  }
];

// GET - Obter todas as avaliações ou avaliações específicas
export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const auditPlanId = searchParams.get('audit_plan_id');
    const auditorId = searchParams.get('auditor_id');
    const requirementSection = searchParams.get('requirement_section');
    
    let filteredEvaluations = [...evaluations];
    
    // Aplicar filtros se fornecidos
    if (auditPlanId) {
      filteredEvaluations = filteredEvaluations.filter(
        eval => eval.audit_plan_id === parseInt(auditPlanId)
      );
    }
    
    if (auditorId) {
      filteredEvaluations = filteredEvaluations.filter(
        eval => eval.auditor_id === parseInt(auditorId)
      );
    }
    
    if (requirementSection) {
      filteredEvaluations = filteredEvaluations.filter(
        eval => eval.requirement_section === requirementSection
      );
    }
    
    return NextResponse.json({ success: true, data: filteredEvaluations });
  } catch (error) {
    console.error('Erro ao buscar avaliações:', error);
    return NextResponse.json(
      { success: false, message: 'Erro ao buscar avaliações' },
      { status: 500 }
    );
  }
}

// POST - Criar ou atualizar uma avaliação
export async function POST(request: Request) {
  try {
    const data = await request.json();
    
    // Validação básica
    if (!data.requirement_section || !data.audit_plan_id || !data.auditor_id) {
      return NextResponse.json(
        { success: false, message: 'Dados incompletos. Seção do requisito, ID do plano de auditoria e ID do auditor são obrigatórios.' },
        { status: 400 }
      );
    }
    
    // Verificar se já existe uma avaliação para este requisito neste plano de auditoria
    const existingIndex = evaluations.findIndex(
      eval => eval.requirement_section === data.requirement_section && 
              eval.audit_plan_id === data.audit_plan_id &&
              eval.auditor_id === data.auditor_id
    );
    
    let result;
    
    if (existingIndex >= 0) {
      // Atualizar avaliação existente
      const updatedEvaluation = {
        ...evaluations[existingIndex],
        ...data,
        updated_at: new Date().toISOString(),
        is_synced: true // Em uma implementação real, isso seria gerenciado pelo sistema de sincronização
      };
      
      evaluations[existingIndex] = updatedEvaluation;
      result = updatedEvaluation;
    } else {
      // Criar nova avaliação
      const newEvaluation = {
        id: evaluations.length + 1,
        ...data,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
        is_synced: true // Em uma implementação real, isso seria gerenciado pelo sistema de sincronização
      };
      
      evaluations.push(newEvaluation);
      result = newEvaluation;
    }
    
    return NextResponse.json({ success: true, data: result });
  } catch (error) {
    console.error('Erro ao salvar avaliação:', error);
    return NextResponse.json(
      { success: false, message: 'Erro ao salvar avaliação' },
      { status: 500 }
    );
  }
}
