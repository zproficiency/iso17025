// src/app/api/requirements/route.ts
import { NextResponse } from 'next/server';

// Dados de exemplo para os requisitos da norma ISO 17025:2017
const requirements = [
  {
    id: 1,
    section: '4',
    title: 'Requisitos Gerais',
    description: 'Requisitos gerais para a competência, imparcialidade e operação consistente de laboratórios.',
    parent_id: null,
    order_index: 1,
    children: [
      {
        id: 11,
        section: '4.1',
        title: 'Imparcialidade',
        description: 'As atividades de laboratório devem ser realizadas com imparcialidade e ser estruturadas e gerenciadas de forma a salvaguardar a imparcialidade.',
        parent_id: 1,
        order_index: 1
      },
      {
        id: 12,
        section: '4.2',
        title: 'Confidencialidade',
        description: 'O laboratório deve ser responsável pela gestão de todas as informações obtidas ou criadas durante a realização de atividades de laboratório.',
        parent_id: 1,
        order_index: 2
      }
    ]
  },
  {
    id: 5,
    section: '8',
    title: 'Requisitos do Sistema de Gestão',
    description: 'Requisitos relacionados ao sistema de gestão do laboratório.',
    parent_id: null,
    order_index: 5,
    children: [
      {
        id: 61,
        section: '8.1',
        title: 'Opções',
        description: 'O laboratório deve estabelecer, documentar, implementar e manter um sistema de gestão.',
        parent_id: 5,
        order_index: 1
      },
      {
        id: 68,
        section: '8.8',
        title: 'Auditorias Internas',
        description: 'O laboratório deve conduzir auditorias internas a intervalos planejados.',
        parent_id: 5,
        order_index: 8,
        children: [
          {
            id: 681,
            section: '8.8.1',
            title: 'Conformidade do Sistema de Gestão',
            description: 'O laboratório deve conduzir auditorias internas a intervalos planejados para prover informações sobre se o sistema de gestão está conforme com os requisitos.',
            parent_id: 68,
            order_index: 1
          },
          {
            id: 682,
            section: '8.8.2',
            title: 'Programa de Auditoria',
            description: 'O laboratório deve planejar, estabelecer, implementar e manter um programa de auditoria.',
            parent_id: 68,
            order_index: 2
          }
        ]
      }
    ]
  }
];

// GET - Obter todos os requisitos ou requisitos específicos
export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const section = searchParams.get('section');
    
    if (section) {
      // Buscar requisito específico por seção
      let foundRequirement = null;
      
      // Função recursiva para encontrar o requisito pela seção
      const findRequirementBySection = (reqs, targetSection) => {
        for (const req of reqs) {
          if (req.section === targetSection) {
            return req;
          }
          if (req.children) {
            const found = findRequirementBySection(req.children, targetSection);
            if (found) return found;
          }
        }
        return null;
      };
      
      foundRequirement = findRequirementBySection(requirements, section);
      
      if (foundRequirement) {
        return NextResponse.json({ success: true, data: foundRequirement });
      } else {
        return NextResponse.json(
          { success: false, message: 'Requisito não encontrado' },
          { status: 404 }
        );
      }
    }
    
    // Retornar todos os requisitos
    return NextResponse.json({ success: true, data: requirements });
  } catch (error) {
    console.error('Erro ao buscar requisitos:', error);
    return NextResponse.json(
      { success: false, message: 'Erro ao buscar requisitos' },
      { status: 500 }
    );
  }
}
