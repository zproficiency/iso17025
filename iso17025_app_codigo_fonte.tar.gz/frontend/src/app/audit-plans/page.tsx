import Link from 'next/link';

export default function AuditPlans() {
  // Dados de exemplo para planos de auditoria
  const auditPlans = [
    {
      id: 1,
      title: 'Auditoria Anual Laboratório Central',
      description: 'Auditoria completa de todos os requisitos da ISO 17025:2017',
      startDate: '2025-05-10',
      endDate: '2025-05-20',
      status: 'active',
      progress: 25,
    },
    {
      id: 2,
      title: 'Auditoria Semestral - Setor de Calibração',
      description: 'Auditoria focada nos requisitos técnicos para o setor de calibração',
      startDate: '2025-06-15',
      endDate: '2025-06-18',
      status: 'draft',
      progress: 0,
    },
    {
      id: 3,
      title: 'Auditoria de Acompanhamento - Não Conformidades',
      description: 'Verificação das ações corretivas implementadas após a última auditoria',
      startDate: '2025-04-05',
      endDate: '2025-04-07',
      status: 'completed',
      progress: 100,
    },
  ];

  // Função para determinar a cor do status
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active':
        return 'bg-green-100 text-green-800';
      case 'draft':
        return 'bg-gray-100 text-gray-800';
      case 'completed':
        return 'bg-blue-100 text-blue-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  // Função para formatar o status
  const formatStatus = (status: string) => {
    switch (status) {
      case 'active':
        return 'Em Andamento';
      case 'draft':
        return 'Rascunho';
      case 'completed':
        return 'Concluído';
      default:
        return status;
    }
  };

  return (
    <div className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
      <div className="px-4 py-6 sm:px-0">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-2xl font-semibold text-gray-900 dark:text-white">Planos de Auditoria</h1>
          <Link
            href="/audit-plans/new"
            className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
          >
            Novo Plano
          </Link>
        </div>

        <div className="bg-white dark:bg-gray-800 shadow overflow-hidden sm:rounded-md">
          <ul className="divide-y divide-gray-200 dark:divide-gray-700">
            {auditPlans.map((plan) => (
              <li key={plan.id}>
                <Link href={`/audit-plans/${plan.id}`} className="block hover:bg-gray-50 dark:hover:bg-gray-700">
                  <div className="px-4 py-4 sm:px-6">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center">
                        <p className="text-sm font-medium text-blue-600 truncate">{plan.title}</p>
                      </div>
                      <div className="ml-2 flex-shrink-0 flex">
                        <p className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusColor(plan.status)}`}>
                          {formatStatus(plan.status)}
                        </p>
                      </div>
                    </div>
                    <div className="mt-2 sm:flex sm:justify-between">
                      <div className="sm:flex">
                        <p className="flex items-center text-sm text-gray-500 dark:text-gray-400">
                          {plan.description}
                        </p>
                      </div>
                      <div className="mt-2 flex items-center text-sm text-gray-500 dark:text-gray-400 sm:mt-0">
                        <p>
                          {new Date(plan.startDate).toLocaleDateString('pt-BR')} até {new Date(plan.endDate).toLocaleDateString('pt-BR')}
                        </p>
                      </div>
                    </div>
                    {plan.status === 'active' && (
                      <div className="mt-2">
                        <div className="relative pt-1">
                          <div className="overflow-hidden h-2 text-xs flex rounded bg-gray-200 dark:bg-gray-700">
                            <div
                              style={{ width: `${plan.progress}%` }}
                              className="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-blue-500"
                            ></div>
                          </div>
                          <div className="text-right mt-1">
                            <span className="text-xs font-semibold inline-block text-blue-600">
                              {plan.progress}% Completo
                            </span>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                </Link>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
}
