"use client";

import { ReactNode } from 'react';
import Link from 'next/link';
import { Inter } from 'next/font/google';
import './globals.css';
import SyncStatusIndicator from '@/components/SyncStatusIndicator';

const inter = Inter({ subsets: ['latin'] });

export const metadata = {
  title: 'Auditoria ISO 17025:2017',
  description: 'Aplicativo para gerenciamento de auditorias conforme a norma ABNT NBR ISO/IEC 17025:2017',
};

interface RootLayoutProps {
  children: ReactNode;
}

export default function RootLayout({ children }: RootLayoutProps) {
  return (
    <html lang="pt-BR">
      <body className={`${inter.className} min-h-screen bg-gray-100 dark:bg-gray-900 text-gray-900 dark:text-gray-100`}>
        <header className="bg-white dark:bg-gray-800 shadow-md">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between h-16">
              <div className="flex">
                <div className="flex-shrink-0 flex items-center">
                  <Link href="/" className="text-xl font-bold text-blue-600">
                    Auditoria ISO 17025
                  </Link>
                </div>
                <nav className="hidden sm:ml-6 sm:flex sm:space-x-8">
                  <Link 
                    href="/audit-plans" 
                    className="border-transparent text-gray-500 dark:text-gray-300 hover:border-gray-300 hover:text-gray-700 dark:hover:text-white inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium"
                  >
                    Planos de Auditoria
                  </Link>
                  <Link 
                    href="/requirements" 
                    className="border-transparent text-gray-500 dark:text-gray-300 hover:border-gray-300 hover:text-gray-700 dark:hover:text-white inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium"
                  >
                    Requisitos
                  </Link>
                  <Link 
                    href="/my-audits" 
                    className="border-transparent text-gray-500 dark:text-gray-300 hover:border-gray-300 hover:text-gray-700 dark:hover:text-white inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium"
                  >
                    Minhas Auditorias
                  </Link>
                  <Link 
                    href="/reports" 
                    className="border-transparent text-gray-500 dark:text-gray-300 hover:border-gray-300 hover:text-gray-700 dark:hover:text-white inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium"
                  >
                    Relatórios
                  </Link>
                </nav>
              </div>
              <div className="hidden sm:ml-6 sm:flex sm:items-center">
                <div className="mr-4">
                  <SyncStatusIndicator />
                </div>
                <div className="ml-3 relative">
                  <div>
                    <button 
                      type="button" 
                      className="bg-white dark:bg-gray-800 rounded-full flex text-sm focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                    >
                      <span className="sr-only">Abrir menu do usuário</span>
                      <div className="h-8 w-8 rounded-full bg-blue-600 flex items-center justify-center text-white">
                        U
                      </div>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </header>
        {children}
        <footer className="bg-white dark:bg-gray-800 shadow-md mt-auto">
          <div className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
            <p className="text-center text-sm text-gray-500 dark:text-gray-400">
              © {new Date().getFullYear()} Aplicativo de Auditoria ISO 17025:2017. Todos os direitos reservados.
            </p>
          </div>
        </footer>
      </body>
    </html>
  );
}
