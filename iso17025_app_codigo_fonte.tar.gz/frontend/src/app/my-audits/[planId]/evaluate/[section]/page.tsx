import { useState } from 'react';
import Link from 'next/link';

export default function RequirementEvaluation({ params }) {
  // Simulando dados de um requisito específico (8.8 - Auditorias Internas)
  const requirement = {
    id: 68,
    section: '8.8',
    title: 'Auditorias Internas',
    description: 'O laboratório deve conduzir auditorias internas a intervalos planejados para prover informações sobre se o sistema de gestão:',
    subItems: [
      {
        id: 681,
        section: '8.8.1',
        text: 'O laboratório deve conduzir auditorias internas a intervalos planejados para prover informações sobre se o sistema de gestão:',
        subPoints: [
          'está conforme com os requisitos do próprio laboratório para o seu sistema de gestão, incluindo as atividades de laboratório;',
          'está conforme com os requisitos deste documento;',
          'está implementado e mantido eficazmente.'
        ]
      },
      {
        id: 682,
        section: '8.8.2',
        text: 'O laboratório deve:',
        subPoints: [
          'planejar, estabelecer, implementar e manter um programa de auditoria, incluindo a frequência, métodos, responsabilidades, requisitos para planejar e o relato, que deve levar em consideração a importância das atividades de laboratório concernentes, mudanças que afetam o laboratório e os resultados de auditorias anteriores;',
          'definir os critérios de auditoria e o escopo para cada auditoria;',
          'assegurar que os resultados das auditorias sejam relatados à gerência pertinente;',
          'implementar correção e ações corretivas apropriadas sem demora indevida;',
          'reter registros como evidência da implementação do programa de auditoria e dos resultados de auditoria.'
        ]
      }
    ]
  };

  // Estado para armazenar a avaliação
  const [evaluation, setEvaluation] = useState({
    status: 'pending',
    procedures: '',
    records: '',
    observations: '',
    evidenceFiles: []
  });

  // Função para atualizar o status
  const handleStatusChange = (status) => {
    setEvaluation({ ...evaluation, status });
  };

  // Função para atualizar campos de texto
  const handleTextChange = (field, value) => {
    setEvaluation({ ...evaluation, [field]: value });
  };

  // Função para simular o envio do formulário
  const handleSubmit = (e) => {
    e.preventDefault();
    alert('Avaliação salva com sucesso!');
    // Aqui seria implementada a lógica para salvar os dados no backend
  };

  return (
    <div className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
      <div className="px-4 py-6 sm:px-0">
        <div className="mb-6">
          <div className="flex items-center">
            <Link 
              href="/my-audits" 
              className="mr-2 text-blue-600 hover:text-blue-800 dark:hover:text-blue-400"
            >
              ← Voltar
            </Link>
            <h1 className="text-2xl font-semibold text-gray-900 dark:text-white">
              Avaliação de Requisito: {requirement.section} - {requirement.title}
            </h1>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 shadow overflow-hidden sm:rounded-md p-6">
          <div className="prose dark:prose-invert max-w-none mb-6">
            <h2>{requirement.section} - {requirement.title}</h2>
            <p>{requirement.description}</p>
            
            {requirement.subItems.map((subItem) => (
              <div key={subItem.id} className="mt-4">
                <h3>{subItem.section}</h3>
                <p>{subItem.text}</p>
                {subItem.subPoints && (
                  <ul>
                    {subItem.subPoints.map((point, index) => (
                      <li key={index}>{point}</li>
                    ))}
                  </ul>
                )}
              </div>
            ))}
          </div>

          <form onSubmit={handleSubmit} className="space-y-6 mt-8 border-t border-gray-200 dark:border-gray-700 pt-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Status de Conformidade
              </label>
              <div className="flex space-x-4">
                <button
                  type="button"
                  onClick={() => handleStatusChange('compliant')}
                  className={`px-4 py-2 rounded-md ${
                    evaluation.status === 'compliant'
                      ? 'bg-green-600 text-white'
                      : 'bg-white dark:bg-gray-700 text-gray-700 dark:text-gray-300 border border-gray-300 dark:border-gray-600'
                  }`}
                >
                  Conforme
                </button>
                <button
                  type="button"
                  onClick={() => handleStatusChange('non_compliant')}
                  className={`px-4 py-2 rounded-md ${
                    evaluation.status === 'non_compliant'
                      ? 'bg-red-600 text-white'
                      : 'bg-white dark:bg-gray-700 text-gray-700 dark:text-gray-300 border border-gray-300 dark:border-gray-600'
                  }`}
                >
                  Não Conforme
                </button>
                <button
                  type="button"
                  onClick={() => handleStatusChange('not_applicable')}
                  className={`px-4 py-2 rounded-md ${
                    evaluation.status === 'not_applicable'
                      ? 'bg-gray-600 text-white'
                      : 'bg-white dark:bg-gray-700 text-gray-700 dark:text-gray-300 border border-gray-300 dark:border-gray-600'
                  }`}
                >
                  Não Aplicável
                </button>
              </div>
            </div>

            <div>
              <label htmlFor="procedures" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Procedimentos Avaliados <span className="text-red-500">*</span>
              </label>
              <textarea
                id="procedures"
                name="procedures"
                rows={4}
                className="shadow-sm focus:ring-blue-500 focus:border-blue-500 block w-full sm:text-sm border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md"
                placeholder="Liste os procedimentos avaliados para este requisito"
                value={evaluation.procedures}
                onChange={(e) => handleTextChange('procedures', e.target.value)}
                required
              />
            </div>

            <div>
              <label htmlFor="records" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Registros Verificados <span className="text-red-500">*</span>
              </label>
              <textarea
                id="records"
                name="records"
                rows={4}
                className="shadow-sm focus:ring-blue-500 focus:border-blue-500 block w-full sm:text-sm border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md"
                placeholder="Liste os registros verificados durante a auditoria"
                value={evaluation.records}
                onChange={(e) => handleTextChange('records', e.target.value)}
                required
              />
            </div>

            <div>
              <label htmlFor="observations" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Observações
              </label>
              <textarea
                id="observations"
                name="observations"
                rows={6}
                className="shadow-sm focus:ring-blue-500 focus:border-blue-500 block w-full sm:text-sm border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-md"
                placeholder="Registre suas observações, evidências e comentários sobre este requisito"
                value={evaluation.observations}
                onChange={(e) => handleTextChange('observations', e.target.value)}
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Evidências (Arquivos)
              </label>
              <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 dark:border-gray-600 border-dashed rounded-md">
                <div className="space-y-1 text-center">
                  <svg
                    className="mx-auto h-12 w-12 text-gray-400"
                    stroke="currentColor"
                    fill="none"
                    viewBox="0 0 48 48"
                    aria-hidden="true"
                  >
                    <path
                      d="M28 8H12a4 4 0 00-4 4v20m32-12v8m0 0v8a4 4 0 01-4 4H12a4 4 0 01-4-4v-4m32-4l-3.172-3.172a4 4 0 00-5.656 0L28 28M8 32l9.172-9.172a4 4 0 015.656 0L28 28m0 0l4 4m4-24h8m-4-4v8m-12 4h.02"
                      strokeWidth={2}
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                  </svg>
                  <div className="flex text-sm text-gray-600 dark:text-gray-400">
                    <label
                      htmlFor="file-upload"
                      className="relative cursor-pointer bg-white dark:bg-gray-700 rounded-md font-medium text-blue-600 hover:text-blue-500 focus-within:outline-none focus-within:ring-2 focus-within:ring-offset-2 focus-within:ring-blue-500"
                    >
                      <span>Carregar arquivos</span>
                      <input id="file-upload" name="file-upload" type="file" className="sr-only" multiple />
                    </label>
                    <p className="pl-1">ou arraste e solte</p>
                  </div>
                  <p className="text-xs text-gray-500 dark:text-gray-400">
                    PNG, JPG, PDF até 10MB
                  </p>
                </div>
              </div>
            </div>

            <div className="flex justify-end space-x-3">
              <button
                type="button"
                className="inline-flex justify-center py-2 px-4 border border-gray-300 dark:border-gray-600 shadow-sm text-sm font-medium rounded-md text-gray-700 dark:text-gray-200 bg-white dark:bg-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
              >
                Salvar Rascunho
              </button>
              <button
                type="submit"
                className="inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
              >
                Concluir Avaliação
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
