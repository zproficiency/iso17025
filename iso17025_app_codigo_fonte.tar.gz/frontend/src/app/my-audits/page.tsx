import Link from 'next/link';

export default function MyAudits() {
  // Dados de exemplo para auditorias atribuídas ao usuário
  const myAudits = [
    {
      id: 1,
      planId: 1,
      planTitle: 'Auditoria Anual Laboratório Central',
      assignedSections: [
        { id: 101, section: '4.1', title: 'Imparcialidade', status: 'completed' },
        { id: 102, section: '4.2', title: 'Confidencialidade', status: 'completed' },
        { id: 103, section: '5.1', title: 'Constituição Legal', status: 'in_progress' },
        { id: 104, section: '5.2', title: 'Identificação da Gestão', status: 'pending' },
      ],
      progress: 50,
      dueDate: '2025-05-15',
    },
    {
      id: 2,
      planId: 2,
      planTitle: 'Auditoria Semestral - Setor de Calibração',
      assignedSections: [
        { id: 201, section: '6.4', title: 'Equipamentos', status: 'pending' },
        { id: 202, section: '6.5', title: 'Rastreabilidade Metrológica', status: 'pending' },
        { id: 203, section: '7.2', title: 'Seleção, Verificação e Validação de Métodos', status: 'pending' },
      ],
      progress: 0,
      dueDate: '2025-06-18',
    },
  ];

  // Função para determinar a cor do status
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'bg-green-100 text-green-800';
      case 'in_progress':
        return 'bg-yellow-100 text-yellow-800';
      case 'pending':
        return 'bg-gray-100 text-gray-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  // Função para formatar o status
  const formatStatus = (status: string) => {
    switch (status) {
      case 'completed':
        return 'Concluído';
      case 'in_progress':
        return 'Em Andamento';
      case 'pending':
        return 'Pendente';
      default:
        return status;
    }
  };

  return (
    <div className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
      <div className="px-4 py-6 sm:px-0">
        <div className="mb-6">
          <h1 className="text-2xl font-semibold text-gray-900 dark:text-white">Minhas Auditorias</h1>
          <p className="mt-2 text-sm text-gray-600 dark:text-gray-400">
            Requisitos da norma ISO 17025:2017 atribuídos a você para auditoria.
          </p>
        </div>

        {myAudits.length > 0 ? (
          <div className="space-y-6">
            {myAudits.map((audit) => (
              <div key={audit.id} className="bg-white dark:bg-gray-800 shadow overflow-hidden sm:rounded-md">
                <div className="px-4 py-4 sm:px-6 border-b border-gray-200 dark:border-gray-700">
                  <div className="flex items-center justify-between">
                    <h2 className="text-lg font-medium text-gray-900 dark:text-white">
                      {audit.planTitle}
                    </h2>
                    <div className="ml-2 flex-shrink-0 flex">
                      <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-blue-100 text-blue-800">
                        {audit.assignedSections.length} requisitos atribuídos
                      </span>
                    </div>
                  </div>
                  <div className="mt-2 flex justify-between">
                    <p className="text-sm text-gray-500 dark:text-gray-400">
                      Data limite: {new Date(audit.dueDate).toLocaleDateString('pt-BR')}
                    </p>
                    <p className="text-sm font-medium text-blue-600">
                      {audit.progress}% concluído
                    </p>
                  </div>
                  <div className="mt-2">
                    <div className="relative pt-1">
                      <div className="overflow-hidden h-2 text-xs flex rounded bg-gray-200 dark:bg-gray-700">
                        <div
                          style={{ width: `${audit.progress}%` }}
                          className="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-blue-500"
                        ></div>
                      </div>
                    </div>
                  </div>
                </div>
                <ul className="divide-y divide-gray-200 dark:divide-gray-700">
                  {audit.assignedSections.map((section) => (
                    <li key={section.id}>
                      <Link 
                        href={`/my-audits/${audit.planId}/evaluate/${section.section}`}
                        className="block hover:bg-gray-50 dark:hover:bg-gray-700"
                      >
                        <div className="px-4 py-4 sm:px-6 flex items-center justify-between">
                          <div className="flex items-center">
                            <div className="ml-3">
                              <p className="text-sm font-medium text-gray-900 dark:text-white">
                                {section.section} - {section.title}
                              </p>
                            </div>
                          </div>
                          <div>
                            <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusColor(section.status)}`}>
                              {formatStatus(section.status)}
                            </span>
                          </div>
                        </div>
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        ) : (
          <div className="bg-white dark:bg-gray-800 shadow overflow-hidden sm:rounded-md p-6 text-center">
            <p className="text-gray-500 dark:text-gray-400">
              Você não tem requisitos atribuídos para auditoria no momento.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
