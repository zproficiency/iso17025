import Link from 'next/link';

export default function Home() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-between p-6 md:p-24">
      <div className="z-10 w-full max-w-5xl items-center justify-between font-mono text-sm">
        <h1 className="text-4xl font-bold text-center mb-8">
          Auditoria ISO 17025:2017
        </h1>
        
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6 mb-8">
          <h2 className="text-2xl font-semibold mb-4">Bem-vindo ao Sistema de Auditoria ISO 17025:2017</h2>
          <p className="mb-4">
            Este aplicativo foi desenvolvido para facilitar a realização de auditorias conforme a norma ABNT NBR ISO/IEC 17025:2017,
            permitindo o gerenciamento completo do processo de auditoria, desde o planejamento até a consolidação dos resultados.
          </p>
          <p className="mb-4">
            Com este sistema, você pode:
          </p>
          <ul className="list-disc pl-6 mb-6 space-y-2">
            <li>Criar e gerenciar planos de auditoria</li>
            <li>Atribuir requisitos específicos a diferentes auditores</li>
            <li>Preencher checklists com procedimentos, registros e observações</li>
            <li>Trabalhar offline e sincronizar quando conectado à internet</li>
            <li>Consolidar resultados de diferentes auditores</li>
            <li>Gerar relatórios completos de auditoria</li>
          </ul>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
            <h3 className="text-xl font-semibold mb-3">Planos de Auditoria</h3>
            <p className="mb-4">
              Crie e gerencie planos de auditoria, definindo escopo, cronograma e responsáveis.
            </p>
            <Link 
              href="/audit-plans" 
              className="inline-block bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-4 rounded transition-colors"
            >
              Acessar Planos
            </Link>
          </div>
          
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
            <h3 className="text-xl font-semibold mb-3">Requisitos da Norma</h3>
            <p className="mb-4">
              Visualize todos os requisitos da norma ISO 17025:2017 organizados por seção.
            </p>
            <Link 
              href="/requirements" 
              className="inline-block bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-4 rounded transition-colors"
            >
              Ver Requisitos
            </Link>
          </div>
          
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
            <h3 className="text-xl font-semibold mb-3">Minhas Auditorias</h3>
            <p className="mb-4">
              Acesse as auditorias atribuídas a você e preencha os checklists correspondentes.
            </p>
            <Link 
              href="/my-audits" 
              className="inline-block bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-4 rounded transition-colors"
            >
              Minhas Auditorias
            </Link>
          </div>
          
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
            <h3 className="text-xl font-semibold mb-3">Relatórios</h3>
            <p className="mb-4">
              Gere relatórios consolidados das auditorias realizadas.
            </p>
            <Link 
              href="/reports" 
              className="inline-block bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-4 rounded transition-colors"
            >
              Ver Relatórios
            </Link>
          </div>
        </div>
        
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
          <h3 className="text-xl font-semibold mb-3">Status de Sincronização</h3>
          <p className="mb-4">
            Este aplicativo funciona offline. Quando você estiver conectado à internet, seus dados serão automaticamente sincronizados com o servidor.
          </p>
          <div className="flex items-center">
            <div className="w-3 h-3 bg-green-500 rounded-full mr-2"></div>
            <p>Todos os dados estão sincronizados</p>
          </div>
        </div>
      </div>
    </main>
  );
}
