import Link from 'next/link';

export default function Reports() {
  // Dados de exemplo para relatórios de auditoria
  const reports = [
    {
      id: 1,
      title: 'Relatório de Auditoria Anual - Laboratório Central',
      auditPlanId: 1,
      completionDate: '2024-12-15',
      totalRequirements: 120,
      compliantCount: 105,
      nonCompliantCount: 12,
      notApplicableCount: 3,
      status: 'completed',
    },
    {
      id: 2,
      title: 'Relatório Semestral - Setor de Calibração',
      auditPlanId: 3,
      completionDate: '2024-09-20',
      totalRequirements: 45,
      compliantCount: 40,
      nonCompliantCount: 5,
      notApplicableCount: 0,
      status: 'completed',
    },
    {
      id: 3,
      title: 'Auditoria Anual Laboratório Central',
      auditPlanId: 5,
      completionDate: null,
      totalRequirements: 120,
      compliantCount: 60,
      nonCompliantCount: 8,
      notApplicableCount: 2,
      status: 'in_progress',
    },
  ];

  // Função para calcular a porcentagem de conformidade
  const calculateCompliancePercentage = (report) => {
    if (report.totalRequirements === 0) return 0;
    const applicableRequirements = report.totalRequirements - report.notApplicableCount;
    if (applicableRequirements === 0) return 100;
    return Math.round((report.compliantCount / applicableRequirements) * 100);
  };

  // Função para determinar a cor do status
  const getStatusColor = (status) => {
    switch (status) {
      case 'completed':
        return 'bg-green-100 text-green-800';
      case 'in_progress':
        return 'bg-yellow-100 text-yellow-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  // Função para formatar o status
  const formatStatus = (status) => {
    switch (status) {
      case 'completed':
        return 'Concluído';
      case 'in_progress':
        return 'Em Andamento';
      default:
        return status;
    }
  };

  return (
    <div className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
      <div className="px-4 py-6 sm:px-0">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-2xl font-semibold text-gray-900 dark:text-white">Relatórios de Auditoria</h1>
          <div className="flex space-x-2">
            <button
              type="button"
              className="inline-flex items-center px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm text-sm font-medium text-gray-700 dark:text-gray-200 bg-white dark:bg-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
            >
              Exportar
            </button>
            <button
              type="button"
              className="inline-flex items-center px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm text-sm font-medium text-gray-700 dark:text-gray-200 bg-white dark:bg-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
            >
              Filtrar
            </button>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 shadow overflow-hidden sm:rounded-md">
          <ul className="divide-y divide-gray-200 dark:divide-gray-700">
            {reports.map((report) => (
              <li key={report.id}>
                <Link href={`/reports/${report.id}`} className="block hover:bg-gray-50 dark:hover:bg-gray-700">
                  <div className="px-4 py-4 sm:px-6">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center">
                        <p className="text-sm font-medium text-blue-600 truncate">{report.title}</p>
                      </div>
                      <div className="ml-2 flex-shrink-0 flex">
                        <p className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusColor(report.status)}`}>
                          {formatStatus(report.status)}
                        </p>
                      </div>
                    </div>
                    <div className="mt-2 sm:flex sm:justify-between">
                      <div className="sm:flex">
                        <p className="flex items-center text-sm text-gray-500 dark:text-gray-400">
                          {report.status === 'completed' 
                            ? `Concluído em: ${new Date(report.completionDate).toLocaleDateString('pt-BR')}`
                            : 'Em andamento'}
                        </p>
                      </div>
                      <div className="mt-2 flex items-center text-sm text-gray-500 dark:text-gray-400 sm:mt-0">
                        <p>
                          Conformidade: {calculateCompliancePercentage(report)}%
                        </p>
                      </div>
                    </div>
                    <div className="mt-4 grid grid-cols-3 gap-4 text-center">
                      <div className="bg-green-50 dark:bg-green-900/20 p-2 rounded">
                        <p className="text-xs text-gray-500 dark:text-gray-400">Conformes</p>
                        <p className="text-lg font-semibold text-green-600 dark:text-green-400">{report.compliantCount}</p>
                      </div>
                      <div className="bg-red-50 dark:bg-red-900/20 p-2 rounded">
                        <p className="text-xs text-gray-500 dark:text-gray-400">Não Conformes</p>
                        <p className="text-lg font-semibold text-red-600 dark:text-red-400">{report.nonCompliantCount}</p>
                      </div>
                      <div className="bg-gray-50 dark:bg-gray-700 p-2 rounded">
                        <p className="text-xs text-gray-500 dark:text-gray-400">Não Aplicáveis</p>
                        <p className="text-lg font-semibold text-gray-600 dark:text-gray-400">{report.notApplicableCount}</p>
                      </div>
                    </div>
                  </div>
                </Link>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
}
