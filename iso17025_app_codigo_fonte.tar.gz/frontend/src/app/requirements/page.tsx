import Link from 'next/link';

export default function Requirements() {
  // Dados de exemplo para os requisitos da norma ISO 17025:2017
  const requirements = [
    {
      id: 1,
      section: '4',
      title: 'Requisitos Gerais',
      subsections: [
        { id: 11, section: '4.1', title: 'Imparcialidade' },
        { id: 12, section: '4.2', title: 'Confidencialidade' }
      ]
    },
    {
      id: 2,
      section: '5',
      title: 'Requisitos de Estrutura',
      subsections: [
        { id: 21, section: '5.1', title: 'Constituição Legal' },
        { id: 22, section: '5.2', title: 'Identificação da Gestão' },
        { id: 23, section: '5.3', title: 'Escopo das Atividades' },
        { id: 24, section: '5.4', title: 'Requisitos Regulamentares' },
        { id: 25, section: '5.5', title: 'Estrutura Organizacional' },
        { id: 26, section: '5.6', title: 'Autoridades e Responsabilidades' },
        { id: 27, section: '5.7', title: 'Comunicação' }
      ]
    },
    {
      id: 3,
      section: '6',
      title: 'Requisitos de Recursos',
      subsections: [
        { id: 31, section: '6.1', title: 'Generalidades' },
        { id: 32, section: '6.2', title: 'Pessoal' },
        { id: 33, section: '6.3', title: 'Instalações e Condições Ambientais' },
        { id: 34, section: '6.4', title: 'Equipamentos' },
        { id: 35, section: '6.5', title: 'Rastreabilidade Metrológica' },
        { id: 36, section: '6.6', title: 'Produtos e Serviços Providos Externamente' }
      ]
    },
    {
      id: 4,
      section: '7',
      title: 'Requisitos de Processo',
      subsections: [
        { id: 41, section: '7.1', title: 'Análise Crítica de Pedidos, Propostas e Contratos' },
        { id: 42, section: '7.2', title: 'Seleção, Verificação e Validação de Métodos' },
        { id: 43, section: '7.3', title: 'Amostragem' },
        { id: 44, section: '7.4', title: 'Manuseio de Itens de Ensaio ou Calibração' },
        { id: 45, section: '7.5', title: 'Registros Técnicos' },
        { id: 46, section: '7.6', title: 'Avaliação da Incerteza de Medição' },
        { id: 47, section: '7.7', title: 'Garantia da Validade dos Resultados' },
        { id: 48, section: '7.8', title: 'Relato de Resultados' },
        { id: 49, section: '7.9', title: 'Reclamações' },
        { id: 50, section: '7.10', title: 'Trabalho Não Conforme' },
        { id: 51, section: '7.11', title: 'Controle de Dados e Gestão da Informação' }
      ]
    },
    {
      id: 5,
      section: '8',
      title: 'Requisitos do Sistema de Gestão',
      subsections: [
        { id: 61, section: '8.1', title: 'Opções' },
        { id: 62, section: '8.2', title: 'Documentação do Sistema de Gestão' },
        { id: 63, section: '8.3', title: 'Controle de Documentos' },
        { id: 64, section: '8.4', title: 'Controle de Registros' },
        { id: 65, section: '8.5', title: 'Ações para Abordar Riscos e Oportunidades' },
        { id: 66, section: '8.6', title: 'Melhoria' },
        { id: 67, section: '8.7', title: 'Ações Corretivas' },
        { id: 68, section: '8.8', title: 'Auditorias Internas' },
        { id: 69, section: '8.9', title: 'Análises Críticas pela Gerência' }
      ]
    }
  ];

  return (
    <div className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
      <div className="px-4 py-6 sm:px-0">
        <div className="mb-6">
          <h1 className="text-2xl font-semibold text-gray-900 dark:text-white">Requisitos da Norma ISO 17025:2017</h1>
          <p className="mt-2 text-sm text-gray-600 dark:text-gray-400">
            Lista completa dos requisitos da norma ABNT NBR ISO/IEC 17025:2017 para auditoria de laboratórios.
          </p>
        </div>

        <div className="bg-white dark:bg-gray-800 shadow overflow-hidden sm:rounded-md">
          <ul className="divide-y divide-gray-200 dark:divide-gray-700">
            {requirements.map((section) => (
              <li key={section.id} className="px-4 py-4 sm:px-6">
                <div className="flex items-center justify-between">
                  <h2 className="text-lg font-medium text-gray-900 dark:text-white">
                    {section.section} - {section.title}
                  </h2>
                  <div className="ml-2 flex-shrink-0 flex">
                    <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-blue-100 text-blue-800">
                      {section.subsections.length} subseções
                    </span>
                  </div>
                </div>
                
                <div className="mt-4 border-t border-gray-200 dark:border-gray-700 pt-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {section.subsections.map((subsection) => (
                      <Link 
                        key={subsection.id} 
                        href={`/requirements/${subsection.section}`}
                        className="block p-3 border border-gray-200 dark:border-gray-700 rounded-md hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
                      >
                        <div className="font-medium text-blue-600">{subsection.section}</div>
                        <div className="text-sm text-gray-600 dark:text-gray-400">{subsection.title}</div>
                      </Link>
                    ))}
                  </div>
                </div>
              </li>
            ))}
          </ul>
        </div>
        
        <div className="mt-6 bg-white dark:bg-gray-800 shadow overflow-hidden sm:rounded-md p-4">
          <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-4">Destaque: Auditorias Internas (8.8)</h3>
          <div className="prose dark:prose-invert max-w-none">
            <p>
              O requisito 8.8 da norma determina a necessidade de que o laboratório estabeleça um programa de auditoria. 
              O laboratório deve conduzir auditorias internas a intervalos planejados para prover informações sobre se o sistema de gestão:
            </p>
            <ul className="list-disc pl-5 mt-2">
              <li>Está conforme com os requisitos do próprio laboratório para o seu sistema de gestão, incluindo as atividades de laboratório</li>
              <li>Está conforme com os requisitos da norma ABNT NBR ISO/IEC 17025</li>
              <li>Está implementado e mantido eficazmente</li>
            </ul>
            <p className="mt-2">
              <Link 
                href="/requirements/8.8" 
                className="text-blue-600 hover:text-blue-800 dark:hover:text-blue-400 font-medium"
              >
                Ver detalhes completos do requisito 8.8 →
              </Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
