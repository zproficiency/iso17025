"use client";

import { useOfflineSync } from '@/hooks/useOfflineSync';

export default function SyncStatusIndicator() {
  const { syncStatus, startSync } = useOfflineSync();
  
  return (
    <div className="flex items-center space-x-2">
      {syncStatus.isOnline ? (
        <div className="flex items-center">
          <div className="w-3 h-3 bg-green-500 rounded-full mr-2"></div>
          <span className="text-sm text-gray-600 dark:text-gray-400">Online</span>
        </div>
      ) : (
        <div className="flex items-center">
          <div className="w-3 h-3 bg-yellow-500 rounded-full mr-2"></div>
          <span className="text-sm text-gray-600 dark:text-gray-400">Offline</span>
        </div>
      )}
      
      {syncStatus.pendingCount > 0 && (
        <div className="flex items-center">
          <button 
            onClick={startSync}
            disabled={syncStatus.syncInProgress || !syncStatus.isOnline}
            className="text-sm text-blue-600 hover:text-blue-800 disabled:text-gray-400 ml-2"
          >
            {syncStatus.syncInProgress 
              ? 'Sincronizando...' 
              : `Sincronizar (${syncStatus.pendingCount} pendentes)`}
          </button>
        </div>
      )}
      
      {syncStatus.errorCount > 0 && (
        <div className="flex items-center">
          <div className="w-3 h-3 bg-red-500 rounded-full mr-2"></div>
          <span className="text-sm text-red-600">{syncStatus.errorCount} erros</span>
        </div>
      )}
      
      {syncStatus.pendingCount === 0 && syncStatus.errorCount === 0 && (
        <div className="flex items-center">
          <span className="text-sm text-gray-600 dark:text-gray-400">Todos os dados sincronizados</span>
        </div>
      )}
    </div>
  );
}
