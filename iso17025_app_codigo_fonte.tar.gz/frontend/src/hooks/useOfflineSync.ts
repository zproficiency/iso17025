"use client";

import { useState, useEffect } from 'react';
import { syncService } from '@/lib/syncService';

export function useOfflineSync() {
  const [syncStatus, setSyncStatus] = useState({
    pendingCount: 0,
    errorCount: 0,
    isOnline: true,
    syncInProgress: false
  });

  // Atualizar o status de sincronização
  const updateSyncStatus = async () => {
    const status = await syncService.getSyncStatus();
    setSyncStatus(status);
  };

  // Iniciar sincronização manual
  const startSync = async () => {
    await syncService.syncData();
    await updateSyncStatus();
  };

  // Carregar dados iniciais do servidor
  const loadInitialData = async () => {
    await syncService.loadInitialData();
    await updateSyncStatus();
  };

  // Monitorar mudanças no status de sincronização
  useEffect(() => {
    // Atualizar status inicial
    updateSyncStatus();

    // Configurar intervalos para verificação periódica
    const intervalId = setInterval(updateSyncStatus, 30000); // A cada 30 segundos

    // Adicionar event listeners para mudanças de conectividade
    const handleOnline = () => {
      updateSyncStatus();
      startSync();
    };

    const handleOffline = () => {
      updateSyncStatus();
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    // Limpar event listeners e intervalos
    return () => {
      clearInterval(intervalId);
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  return {
    syncStatus,
    startSync,
    loadInitialData
  };
}
