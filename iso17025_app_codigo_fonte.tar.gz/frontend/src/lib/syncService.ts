"use client";

// src/lib/syncService.ts
import { openDB } from 'idb';

// Definição do banco de dados IndexedDB
const DB_NAME = 'iso17025_audit_app';
const DB_VERSION = 1;

// Definição das stores do IndexedDB
const STORES = {
  AUDIT_PLANS: 'audit_plans',
  REQUIREMENTS: 'requirements',
  EVALUATIONS: 'evaluations',
  SYNC_QUEUE: 'sync_queue',
  USER_DATA: 'user_data'
};

// Inicializar o banco de dados IndexedDB
export async function initializeDB() {
  return openDB(DB_NAME, DB_VERSION, {
    upgrade(db) {
      // Criar stores se não existirem
      if (!db.objectStoreNames.contains(STORES.AUDIT_PLANS)) {
        const auditPlansStore = db.createObjectStore(STORES.AUDIT_PLANS, { keyPath: 'id' });
        auditPlansStore.createIndex('status', 'status');
        auditPlansStore.createIndex('createdBy', 'createdBy');
      }

      if (!db.objectStoreNames.contains(STORES.REQUIREMENTS)) {
        const requirementsStore = db.createObjectStore(STORES.REQUIREMENTS, { keyPath: 'id' });
        requirementsStore.createIndex('section', 'section');
        requirementsStore.createIndex('parent_id', 'parent_id');
      }

      if (!db.objectStoreNames.contains(STORES.EVALUATIONS)) {
        const evaluationsStore = db.createObjectStore(STORES.EVALUATIONS, { keyPath: 'id' });
        evaluationsStore.createIndex('audit_plan_id', 'audit_plan_id');
        evaluationsStore.createIndex('auditor_id', 'auditor_id');
        evaluationsStore.createIndex('requirement_section', 'requirement_section');
        evaluationsStore.createIndex('is_synced', 'is_synced');
      }

      if (!db.objectStoreNames.contains(STORES.SYNC_QUEUE)) {
        const syncQueueStore = db.createObjectStore(STORES.SYNC_QUEUE, { keyPath: 'id', autoIncrement: true });
        syncQueueStore.createIndex('entity_type', 'entity_type');
        syncQueueStore.createIndex('status', 'status');
      }

      if (!db.objectStoreNames.contains(STORES.USER_DATA)) {
        db.createObjectStore(STORES.USER_DATA, { keyPath: 'id' });
      }
    }
  });
}

// Classe para gerenciar a sincronização
export class SyncService {
  private db;
  private isOnline = navigator.onLine;
  private syncInProgress = false;

  constructor() {
    // Inicializar o banco de dados
    this.initialize();

    // Adicionar event listeners para monitorar o status da conexão
    window.addEventListener('online', this.handleOnline.bind(this));
    window.addEventListener('offline', this.handleOffline.bind(this));
  }

  private async initialize() {
    try {
      this.db = await initializeDB();
      console.log('IndexedDB inicializado com sucesso');

      // Se estiver online, tentar sincronizar imediatamente
      if (this.isOnline) {
        this.syncData();
      }
    } catch (error) {
      console.error('Erro ao inicializar IndexedDB:', error);
    }
  }

  private handleOnline() {
    console.log('Conexão online detectada');
    this.isOnline = true;
    this.syncData();
  }

  private handleOffline() {
    console.log('Conexão offline detectada');
    this.isOnline = false;
  }

  // Método para sincronizar dados com o servidor
  public async syncData() {
    if (!this.isOnline || this.syncInProgress) {
      return;
    }

    try {
      this.syncInProgress = true;
      console.log('Iniciando sincronização de dados...');

      // Buscar itens na fila de sincronização
      const syncItems = await this.db.getAllFromIndex(STORES.SYNC_QUEUE, 'status', 'pending');

      if (syncItems.length === 0) {
        console.log('Nenhum item pendente para sincronização');
        this.syncInProgress = false;
        return;
      }

      console.log(`${syncItems.length} itens encontrados para sincronização`);

      // Processar cada item da fila
      for (const item of syncItems) {
        try {
          await this.processSyncItem(item);
        } catch (error) {
          console.error(`Erro ao processar item de sincronização ${item.id}:`, error);
          
          // Atualizar o status do item na fila
          await this.db.put(STORES.SYNC_QUEUE, {
            ...item,
            status: 'error',
            error_message: error.message,
            sync_attempt_count: (item.sync_attempt_count || 0) + 1,
            last_attempt: new Date().toISOString()
          });
        }
      }

      console.log('Sincronização concluída');
    } catch (error) {
      console.error('Erro durante a sincronização:', error);
    } finally {
      this.syncInProgress = false;
    }
  }

  // Processar um item da fila de sincronização
  private async processSyncItem(item) {
    console.log(`Processando item de sincronização: ${item.id}, tipo: ${item.entity_type}, operação: ${item.operation}`);

    // Determinar a URL da API com base no tipo de entidade
    let apiUrl;
    switch (item.entity_type) {
      case 'audit_plan':
        apiUrl = '/api/audit-plans';
        break;
      case 'evaluation':
        apiUrl = '/api/evaluations';
        break;
      default:
        throw new Error(`Tipo de entidade desconhecido: ${item.entity_type}`);
    }

    // Determinar o método HTTP com base na operação
    let method;
    switch (item.operation) {
      case 'create':
        method = 'POST';
        break;
      case 'update':
        method = 'PUT';
        break;
      case 'delete':
        method = 'DELETE';
        break;
      default:
        throw new Error(`Operação desconhecida: ${item.operation}`);
    }

    // Obter o token de autenticação
    const userData = await this.getUserData();
    if (!userData || !userData.token) {
      throw new Error('Usuário não autenticado');
    }

    // Enviar a requisição para o servidor
    const response = await fetch(apiUrl, {
      method,
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${userData.token}`
      },
      body: JSON.stringify(item.data)
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.message || 'Erro na sincronização com o servidor');
    }

    const responseData = await response.json();

    // Atualizar o item local com os dados do servidor
    if (item.operation !== 'delete') {
      await this.db.put(this.getStoreNameForEntityType(item.entity_type), {
        ...responseData.data,
        is_synced: true
      });
    } else if (item.operation === 'delete') {
      await this.db.delete(this.getStoreNameForEntityType(item.entity_type), item.data.id);
    }

    // Marcar o item como sincronizado na fila
    await this.db.put(STORES.SYNC_QUEUE, {
      ...item,
      status: 'synced',
      synced_at: new Date().toISOString()
    });

    console.log(`Item ${item.id} sincronizado com sucesso`);
  }

  // Obter o nome da store com base no tipo de entidade
  private getStoreNameForEntityType(entityType) {
    switch (entityType) {
      case 'audit_plan':
        return STORES.AUDIT_PLANS;
      case 'evaluation':
        return STORES.EVALUATIONS;
      default:
        throw new Error(`Tipo de entidade desconhecido: ${entityType}`);
    }
  }

  // Adicionar um item à fila de sincronização
  public async addToSyncQueue(entityType, operation, data) {
    const syncItem = {
      entity_type: entityType,
      operation,
      data,
      status: 'pending',
      created_at: new Date().toISOString(),
      sync_attempt_count: 0
    };

    await this.db.add(STORES.SYNC_QUEUE, syncItem);

    // Se estiver online, tentar sincronizar imediatamente
    if (this.isOnline) {
      this.syncData();
    }
  }

  // Salvar dados do usuário localmente
  public async saveUserData(userData) {
    await this.db.put(STORES.USER_DATA, { id: 'current_user', ...userData });
  }

  // Obter dados do usuário
  public async getUserData() {
    return this.db.get(STORES.USER_DATA, 'current_user');
  }

  // Limpar dados do usuário (logout)
  public async clearUserData() {
    await this.db.delete(STORES.USER_DATA, 'current_user');
  }

  // Verificar status de sincronização
  public async getSyncStatus() {
    const pendingCount = await this.db.countFromIndex(STORES.SYNC_QUEUE, 'status', 'pending');
    const errorCount = await this.db.countFromIndex(STORES.SYNC_QUEUE, 'status', 'error');
    
    return {
      pendingCount,
      errorCount,
      isOnline: this.isOnline,
      syncInProgress: this.syncInProgress
    };
  }

  // Métodos para operações CRUD com suporte offline

  // Criar ou atualizar plano de auditoria
  public async saveAuditPlan(auditPlan) {
    const isNew = !auditPlan.id;
    
    // Gerar ID temporário para novos planos
    if (isNew) {
      auditPlan.id = `temp_${Date.now()}`;
      auditPlan.created_at = new Date().toISOString();
    }
    
    auditPlan.updated_at = new Date().toISOString();
    auditPlan.is_synced = false;
    
    // Salvar localmente
    await this.db.put(STORES.AUDIT_PLANS, auditPlan);
    
    // Adicionar à fila de sincronização
    await this.addToSyncQueue(
      'audit_plan',
      isNew ? 'create' : 'update',
      auditPlan
    );
    
    return auditPlan;
  }

  // Criar ou atualizar avaliação
  public async saveEvaluation(evaluation) {
    const isNew = !evaluation.id;
    
    // Gerar ID temporário para novas avaliações
    if (isNew) {
      evaluation.id = `temp_${Date.now()}`;
      evaluation.created_at = new Date().toISOString();
    }
    
    evaluation.updated_at = new Date().toISOString();
    evaluation.is_synced = false;
    
    // Salvar localmente
    await this.db.put(STORES.EVALUATIONS, evaluation);
    
    // Adicionar à fila de sincronização
    await this.addToSyncQueue(
      'evaluation',
      isNew ? 'create' : 'update',
      evaluation
    );
    
    return evaluation;
  }

  // Obter planos de auditoria
  public async getAuditPlans() {
    return this.db.getAll(STORES.AUDIT_PLANS);
  }

  // Obter avaliações
  public async getEvaluations(filters = {}) {
    const allEvaluations = await this.db.getAll(STORES.EVALUATIONS);
    
    // Aplicar filtros se fornecidos
    return allEvaluations.filter(evaluation => {
      let match = true;
      
      if (filters.audit_plan_id !== undefined) {
        match = match && evaluation.audit_plan_id === filters.audit_plan_id;
      }
      
      if (filters.auditor_id !== undefined) {
        match = match && evaluation.auditor_id === filters.auditor_id;
      }
      
      if (filters.requirement_section !== undefined) {
        match = match && evaluation.requirement_section === filters.requirement_section;
      }
      
      return match;
    });
  }

  // Obter requisitos
  public async getRequirements() {
    return this.db.getAll(STORES.REQUIREMENTS);
  }

  // Carregar dados iniciais do servidor
  public async loadInitialData() {
    if (!this.isOnline) {
      console.log('Offline: não é possível carregar dados iniciais');
      return;
    }

    try {
      // Carregar requisitos
      const requirementsResponse = await fetch('/api/requirements');
      if (requirementsResponse.ok) {
        const requirementsData = await requirementsResponse.json();
        
        // Função recursiva para salvar requisitos e seus filhos
        const saveRequirements = async (requirements) => {
          for (const req of requirements) {
            const children = req.children;
            delete req.children;
            
            await this.db.put(STORES.REQUIREMENTS, { ...req, is_synced: true });
            
            if (children && children.length > 0) {
              await saveRequirements(children);
            }
          }
        };
        
        await saveRequirements(requirementsData.data);
        console.log('Requisitos carregados com sucesso');
      }

      // Carregar planos de auditoria
      const plansResponse = await fetch('/api/audit-plans');
      if (plansResponse.ok) {
        const plansData = await plansResponse.json();
        
        for (const plan of plansData.data) {
          await this.db.put(STORES.AUDIT_PLANS, { ...plan, is_synced: true });
        }
        
        console.log('Planos de auditoria carregados com sucesso');
      }

      // Carregar avaliações do usuário atual
      const userData = await this.getUserData();
      if (userData && userData.id) {
        const evaluationsResponse = await fetch(`/api/evaluations?auditor_id=${userData.id}`);
        if (evaluationsResponse.ok) {
          const evaluationsData = await evaluationsResponse.json();
          
          for (const evaluation of evaluationsData.data) {
            await this.db.put(STORES.EVALUATIONS, { ...evaluation, is_synced: true });
          }
          
          console.log('Avaliações carregadas com sucesso');
        }
      }

      console.log('Dados iniciais carregados com sucesso');
    } catch (error) {
      console.error('Erro ao carregar dados iniciais:', error);
    }
  }
}

// Exportar uma instância única do serviço de sincronização
export const syncService = new SyncService();
